import { useEffect, useMemo, useState } from 'react';
import type { CombinedSubjectGroup, QuestionPaperDraft, QuestionPaperExam, QuestionPaperSourceMode, QuestionPatternRow, StudyMaterial, TeacherAssignment } from '../types/domain';
import { generateQuestionPaperDraft, listStudyMaterialChapters, prepareHomeworkTextbookSource } from '../services/teacherAcademicService';

const examLabels: Record<QuestionPaperExam,string> = {
  first_unit_test:'First Unit Test', first_term_examination:'First Term Examination', second_unit_test:'Second Unit Test', second_term_examination:'Second Term Examination'
};
type Family='general'|'science'|'maths'|'language'|'social'|'art'|'computer';
const family=(a?:TeacherAssignment|null):Family=>{const v=`${a?.subjectName||''} ${a?.subjectCode||''}`.toLowerCase();if(/math|algebra|geometry|arithmetic|ganit/.test(v))return'maths';if(/drawing|art|craft/.test(v))return'art';if(/computer|ict|coding|information technology/.test(v))return'computer';if(/science|evs|environment|physics|chemistry|biology/.test(v))return'science';if(/history|geography|civics|social|political science|economics/.test(v))return'social';if(/english|urdu|hindi|marathi|sanskrit|gujarati|kannada|tamil|telugu|malayalam|bengali|punjabi|odia|assamese|kashmiri|sindhi|language/.test(v))return'language';return'general';};
const typesByFamily:Record<Family,string[]>={
  general:['MCQ','Fill in the Blanks','True / False','Match the Following','Very Short Answer','Short Answer','Long Answer'],
  science:['MCQ','Fill in the Blanks','True / False','Match the Following','Very Short Answer','Short Answer','Long Answer','Definitions / Terms','Give Reasons','Diagram / Labeling','Observation / Activity'],
  maths:['MCQ','Fill in the Blanks','Solve Problems / Sums','Word Problems','Mental Maths','Show Complete Working','Geometry / Construction','Very Short Answer','Short Answer'],
  language:['MCQ','Fill in the Blanks','Match the Following','Very Short Answer','Short Answer','Long Answer','Grammar / Language Practice','Comprehension','Vocabulary / Word Meaning','Sentence Making','Writing / Essay'],
  social:['MCQ','Fill in the Blanks','True / False','Match the Following','Very Short Answer','Short Answer','Long Answer','Map Work','Timeline / Sequence','Identify / Name','Cause & Effect'],
  art:['Drawing','Sketching','Colouring','Pattern / Design','Observation Drawing','Creative Composition','Craft / Activity'],
  computer:['MCQ','Fill in the Blanks','True / False','Match the Following','Very Short Answer','Short Answer','Long Answer','Practical Task','Lab Exercise','Shortcut Keys','Identify Parts / Components'],
};
const basePattern=(a?:TeacherAssignment|null):QuestionPatternRow[]=>{switch(family(a)){case'maths':return[{type:'MCQ',count:5,marksEach:1},{type:'Solve Problems / Sums',count:5,marksEach:3},{type:'Word Problems',count:4,marksEach:5}];case'language':return[{type:'Fill in the Blanks',count:5,marksEach:1},{type:'Grammar / Language Practice',count:5,marksEach:1},{type:'Short Answer',count:5,marksEach:2},{type:'Long Answer',count:4,marksEach:5}];case'art':return[{type:'Drawing',count:2,marksEach:10},{type:'Creative Composition',count:2,marksEach:10}];case'computer':return[{type:'MCQ',count:5,marksEach:1},{type:'Fill in the Blanks',count:5,marksEach:1},{type:'Practical Task',count:5,marksEach:2},{type:'Short Answer',count:4,marksEach:5}];default:return[{type:'MCQ',count:5,marksEach:1},{type:'Fill in the Blanks',count:5,marksEach:1},{type:'Short Answer',count:5,marksEach:2},{type:'Long Answer',count:4,marksEach:5}];}};
const patternTotal=(rows:QuestionPatternRow[])=>rows.reduce((s,r)=>s+Number(r.count||0)*Number(r.marksEach||0),0);
const fitPattern=(assignment:TeacherAssignment|undefined,target:number):QuestionPatternRow[]=>{
  const amount=Math.max(1,Math.floor(target||1));const base=basePattern(assignment);const out:QuestionPatternRow[]=[];let left=amount;
  for(const row of base){if(left<=0)break;const each=Math.max(1,Math.floor(row.marksEach));const count=Math.min(row.count,Math.floor(left/each));if(count>0){out.push({...row,count});left-=count*each;}}
  if(left>0){const oneMark=typesByFamily[family(assignment)].find(t=>!/long|essay|drawing|creative|word problem|solve|working|practical|lab/i.test(t))||'Very Short Answer';out.push({type:oneMark,count:left,marksEach:1});}
  return out;
};
const splitMarks=(group:CombinedSubjectGroup,total:number,index:number)=>{
  const suggestions=group.members.map(m=>Number(m.suggestedMarks||0));
  if(suggestions.every(v=>v>0))return suggestions[index];
  const base=Math.floor(Math.max(1,total)/group.members.length), rem=Math.max(1,total)-base*group.members.length;
  return base+(index<rem?1:0);
};

type ComponentState={marks:number;chapters:string[];chapterOptions:string[];loading:boolean;whole:boolean;exercise:boolean;pattern:QuestionPatternRow[];useSaved:boolean;};
type Props={group:CombinedSubjectGroup;currentAssignment:TeacherAssignment;assignments:TeacherAssignment[];materials:StudyMaterial[];exam:QuestionPaperExam;combinedTotalMarks:number;durationMinutes:number;onTotalMarksChange:(value:number)=>void;onGenerated:(paper:QuestionPaperDraft)=>void;onBusy:(value:boolean)=>void;onError:(message:string)=>void;};

export function CombinedQuestionPaperBuilder({group,currentAssignment,assignments,materials,exam,combinedTotalMarks,durationMinutes,onTotalMarksChange,onGenerated,onBusy,onError}:Props){
  const editableMembers=useMemo(()=>group.currentTeacherHasAll?group.members:group.members.filter(m=>String(m.subjectId)===String(currentAssignment.subjectId)&&m.assignedToCurrentTeacher),[group,currentAssignment.subjectId]);
  const [states,setStates]=useState<Record<string,ComponentState>>({});

  useEffect(()=>{
    const suggestedSum=group.members.reduce((sum,m)=>sum+Number(m.suggestedMarks||0),0);
    if(group.members.every(m=>Number(m.suggestedMarks||0)>0)&&suggestedSum>0&&suggestedSum!==combinedTotalMarks)onTotalMarksChange(suggestedSum);
  },[group.id]);

  useEffect(()=>{
    let cancelled=false;
    const initial:Record<string,ComponentState>={};
    group.members.forEach((m,index)=>{const a=assignments.find(x=>x.id===m.assignmentId);const marks=splitMarks(group,combinedTotalMarks,index);initial[m.subjectId]={marks,chapters:[],chapterOptions:[],loading:Boolean(m.assignedToCurrentTeacher),whole:true,exercise:true,pattern:m.savedPattern?.length?m.savedPattern:fitPattern(a,marks),useSaved:Boolean(m.savedPattern?.length)};});
    setStates(initial);
    for(const member of editableMembers){const a=assignments.find(x=>x.id===member.assignmentId);if(!a)continue;const ids=materials.filter(m=>m.category==='textbook'&&!m.archived&&m.extractionStatus==='ready'&&String(m.className)===String(a.className)&&String(m.subjectId)===String(a.subjectId)).map(m=>m.id);if(!ids.length){setStates(cur=>({...cur,[member.subjectId]:{...cur[member.subjectId],loading:false}}));continue;}void listStudyMaterialChapters(ids).then(rows=>{if(!cancelled)setStates(cur=>({...cur,[member.subjectId]:{...cur[member.subjectId],chapterOptions:rows,loading:false}}));}).catch(()=>{if(!cancelled)setStates(cur=>({...cur,[member.subjectId]:{...cur[member.subjectId],loading:false}}));});void prepareHomeworkTextbookSource(ids).catch(()=>undefined);}
    return()=>{cancelled=true;};
  },[group.id,editableMembers.map(m=>m.assignmentId).join('|')]);

  useEffect(()=>{
    setStates(cur=>{const next={...cur};group.members.forEach((m,index)=>{const old=next[m.subjectId];if(!old||old.useSaved)return;const marks=splitMarks(group,combinedTotalMarks,index);next[m.subjectId]={...old,marks,pattern:fitPattern(assignments.find(a=>a.id===m.assignmentId),marks)};});return next;});
  },[combinedTotalMarks]);

  const update=(subjectId:string,patch:Partial<ComponentState>)=>setStates(cur=>({...cur,[subjectId]:{...cur[subjectId],...patch}}));
  const expectedComponents=group.members.map((m,index)=>({subjectId:m.subjectId,subjectName:m.subjectName,assignmentId:m.assignmentId,teacherName:m.teacherName,marks:states[m.subjectId]?.marks||splitMarks(group,combinedTotalMarks,index)}));
  const workflow: 'single_teacher_combined' | 'collaborative_component' = group.currentTeacherHasAll?'single_teacher_combined':'collaborative_component';

  const generate=async()=>{
    onError('');onBusy(true);
    try{
      if(group.members.some(m=>!m.assigned))throw new Error('One or more Subjects in this Combined Group are not assigned for the selected Class/Division. Complete Academic Assignments first.');
      const total=group.members.reduce((sum,m)=>sum+Number(states[m.subjectId]?.marks||0),0);if(total!==combinedTotalMarks)throw new Error(`Combined Subject sections total ${total} marks, but Combined Total Marks is ${combinedTotalMarks}.`);
      const targets=group.currentTeacherHasAll?group.members:editableMembers;if(!targets.length)throw new Error('This Teacher has no editable component in the selected Combined Subject Group.');
      const generatedParts:Array<{member:any;paper:QuestionPaperDraft}>=[];
      for(const member of targets){const a=assignments.find(x=>x.id===member.assignmentId);const st=states[member.subjectId];if(!a||!st)throw new Error(`${member.subjectName} assignment is unavailable.`);const textbooks=materials.filter(m=>m.category==='textbook'&&!m.archived&&m.extractionStatus==='ready'&&String(m.className)===String(a.className)&&String(m.subjectId)===String(a.subjectId));if(!textbooks.length)throw new Error(`${member.subjectName} Textbook is not AI Ready.`);if(!st.whole&&!st.exercise)throw new Error(`Select Whole Chapter or Mashq / Exercise for ${member.subjectName}.`);if(patternTotal(st.pattern)!==st.marks)throw new Error(`${member.subjectName} pattern totals ${patternTotal(st.pattern)} marks, expected ${st.marks}.`);const source:QuestionPaperSourceMode=st.whole&&st.exercise?'both':st.exercise?'exercise':'whole_chapter';const p=await generateQuestionPaperDraft({taskType:'question-paper',assignmentId:a.id,materialIds:textbooks.map(m=>m.id),chapterScope:st.chapters,prompt:`Create the ${member.subjectName} component of the ${group.groupName} combined ${examLabels[exam]}. Use only this Subject Textbook. Component marks: ${st.marks}.`,structuredInputs:{exam,totalMarks:st.marks,durationMinutes,useSchoolPattern:Boolean(member.savedPattern?.length),manualPattern:member.savedPattern?.length?[]:st.pattern,sourcePolicy:'textbook_only_auto',questionSource:source,languagePolicy:'textbook_subject_language_auto',chapterSelectionMode:st.chapters.length?'selected_chapters':'whole_textbook'}});generatedParts.push({member,paper:p});}
      if(!group.currentTeacherHasAll){const {member,paper}=generatedParts[0];const componentIndex=group.members.findIndex(m=>m.subjectId===member.subjectId)+1;const enriched=paper.pattern.map(row=>({...row,combinedGroupId:group.id,combinedGroupName:group.groupName,collaborationKey:group.collaborationKey,combinedWorkflow:workflow,componentSubjectId:member.subjectId,componentSubjectName:member.subjectName,componentAssignmentId:member.assignmentId,componentIndex,componentTotalMarks:paper.totalMarks,combinedTotalMarks,expectedComponents,componentInstructions:paper.instructions}));onGenerated({...paper,pattern:enriched,instructions:[],combinedMeta:{groupId:group.id,groupName:group.groupName,collaborationKey:group.collaborationKey,workflow,componentSubjectId:member.subjectId,componentSubjectName:member.subjectName,combinedTotalMarks},reviewStatus:'ai_draft'});return;}
      let sectionOffset=0,orderOffset=0;const patterns:QuestionPatternRow[]=[],questions:any[]=[],materialIds:string[]=[],chapters:string[]=[];
      for(let partIndex=0;partIndex<generatedParts.length;partIndex++){const {member,paper}=generatedParts[partIndex];for(const id of paper.materialIds)if(!materialIds.includes(id))materialIds.push(id);for(const ch of paper.chapters){const label=`${member.subjectName}: ${ch}`;if(!chapters.includes(label))chapters.push(label);}paper.pattern.forEach(row=>patterns.push({...row,combinedGroupId:group.id,combinedGroupName:group.groupName,collaborationKey:group.collaborationKey,combinedWorkflow:workflow,componentSubjectId:member.subjectId,componentSubjectName:member.subjectName,componentAssignmentId:member.assignmentId,componentIndex:partIndex+1,componentTotalMarks:paper.totalMarks,combinedTotalMarks,expectedComponents,componentInstructions:paper.instructions}));paper.questions.forEach(q=>questions.push({...q,sectionIndex:Number(q.sectionIndex||1)+sectionOffset,orderNo:Number(q.orderNo||1)+orderOffset}));sectionOffset+=paper.pattern.length;orderOffset+=paper.questions.length;}
      const first=generatedParts[0].paper;onGenerated({...first,assignmentId:generatedParts[0].member.assignmentId,materialIds,chapters,totalMarks:combinedTotalMarks,durationMinutes,medium:'Combined',title:`${examLabels[exam]} — ${group.groupName}`,instructions:[],pattern:patterns,questions,combinedMeta:{groupId:group.id,groupName:group.groupName,collaborationKey:group.collaborationKey,workflow,combinedTotalMarks},reviewStatus:'ai_draft'});
    }catch(e){onError(e instanceof Error?e.message:'Combined Question Paper generation failed.');}finally{onBusy(false);}
  };

  return <div className="combined-paper-builder">
    <div className="combined-paper-summary"><div><strong>{group.groupName}</strong><small>{group.currentTeacherHasAll?'All components are assigned to you — one complete combined paper will be generated.':'Different teachers are assigned — you will prepare only your Subject section and submit it to Clerk.'}</small></div><span>{group.members.length} Subjects</span></div>
    {!group.currentTeacherHasAll&&<div className="combined-collab-status">{group.members.map((m,i)=><div key={m.subjectId}><b>Part {String.fromCharCode(65+i)} · {m.subjectName}</b><span>{m.assignedToCurrentTeacher?'Your section':m.teacherName||'Teacher not assigned'}</span><em className={m.latestSubmission?.status||''}>{m.latestSubmission?.status==='returned'?`Returned${m.latestSubmission.reason?`: ${m.latestSubmission.reason}`:''}`:m.latestSubmission?.status==='approved'?'Approved by Clerk':m.latestSubmission?.status==='submitted'?'Submitted to Clerk':'Pending'}</em></div>)}</div>}
    <div className="combined-component-grid">{editableMembers.map((member)=>{const a=assignments.find(x=>x.id===member.assignmentId);const st=states[member.subjectId];if(!st)return null;const types=typesByFamily[family(a)];return <div className="combined-component-card" key={member.subjectId}>
      <div className="card-title-row"><div><h3>{member.subjectName}</h3><small>{member.teacherName||'Assigned Teacher'}{member.savedPattern?.length?' · Saved school pattern':''}</small></div><strong>{st.marks} marks</strong></div>
      <label className="field"><span>{group.currentTeacherHasAll?'Component Marks':'My Section Marks'}</span><input type="number" min={1} value={st.marks} disabled={Boolean(member.savedPattern?.length) || !group.currentTeacherHasAll} onChange={e=>{const marks=Number(e.target.value);update(member.subjectId,{marks,pattern:fitPattern(a,marks)});}} /></label>
      <div className="field"><span>Chapters</span><details className="question-multi-select"><summary>{st.loading?'Reading chapters…':st.chapters.length?`${st.chapters.length} selected`:'Whole textbook'}</summary><div className="question-multi-panel"><label className="question-check-row whole"><input type="checkbox" checked={!st.chapters.length} onChange={()=>update(member.subjectId,{chapters:[]})}/><span>Whole textbook</span></label>{st.chapterOptions.map(ch=><label className="question-check-row" key={ch}><input type="checkbox" checked={st.chapters.includes(ch)} onChange={()=>{const set=new Set(st.chapters);set.has(ch)?set.delete(ch):set.add(ch);update(member.subjectId,{chapters:st.chapterOptions.filter(x=>set.has(x))});}}/><span>{ch}</span></label>)}</div></details></div>
      <div className="field"><span>Question Source</span><div className="combined-source-row"><label><input type="checkbox" checked={st.whole} onChange={e=>update(member.subjectId,{whole:e.target.checked})}/> Whole Chapter</label><label><input type="checkbox" checked={st.exercise} onChange={e=>update(member.subjectId,{exercise:e.target.checked})}/> Mashq / Exercise</label></div></div>
      {member.savedPattern?.length?<div className="question-pattern-preview"><strong>Saved Pattern</strong><div className="question-pattern-chips">{member.savedPattern.map((r,i)=><span key={`${r.type}-${i}`}>{r.type}: {r.count} × {r.marksEach}</span>)}</div></div>:<div className="pattern-box compact"><div className="card-title-row"><h3>Paper Pattern</h3><small>{patternTotal(st.pattern)}/{st.marks}</small></div>{st.pattern.map((row,i)=><div className="pattern-row" key={`${member.subjectId}-${i}`}><select value={types.includes(row.type)?row.type:types[0]} onChange={e=>update(member.subjectId,{pattern:st.pattern.map((r,x)=>x===i?{...r,type:e.target.value}:r)})}>{types.map(t=><option value={t} key={t}>{t}</option>)}</select><input type="number" min={1} value={row.count} onChange={e=>update(member.subjectId,{pattern:st.pattern.map((r,x)=>x===i?{...r,count:Number(e.target.value)}:r)})}/><span>×</span><input type="number" min={1} value={row.marksEach} onChange={e=>update(member.subjectId,{pattern:st.pattern.map((r,x)=>x===i?{...r,marksEach:Number(e.target.value)}:r)})}/><button className="icon-btn" type="button" onClick={()=>update(member.subjectId,{pattern:st.pattern.filter((_,x)=>x!==i)})}>×</button></div>)}<button className="btn ghost" type="button" onClick={()=>update(member.subjectId,{pattern:[...st.pattern,{type:types[0],count:1,marksEach:1}]})}>+ Add Type</button></div>}
    </div>;})}</div>
    <div className="combined-total-note"><strong>Combined Total:</strong> {group.members.reduce((sum,m)=>sum+Number(states[m.subjectId]?.marks||0),0)} / {combinedTotalMarks} marks</div>
    <div className="actions"><button className="btn primary" type="button" onClick={()=>void generate()}>{group.currentTeacherHasAll?'Generate Complete Combined Paper':'Generate My Section for Clerk'}</button></div>
  </div>;
}
